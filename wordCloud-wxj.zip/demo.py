# # coding:utf-8
#
# from os import path
# import chnSegment
# import plotWordcloud
#
#
# if __name__=='__main__':
#
#     # 读取文件
#     d = path.dirname(__file__)
#     text = open(path.join(d, 'doc//十九大报告全文.txt')).read()

#     # 若是中文文本，则先进行分词操作
#     text=chnSegment.word_segment(text)
#
#     # 生成词云
#     plotWordcloud.generate_wordcloud(text)
# coding:utf-8
# 优化版
from os import path
import chnSegment
import plotWordcloud

if __name__ == '__main__':
    # 读取文件
    d = path.dirname(__file__)
    file_path = path.join(d, 'doc', '25年新年贺词.txt')
    try:
        # 尝试使用 utf-8 编码打开文件
        with open(file_path, 'r', encoding='utf-8') as file:
            text = file.read()
    except UnicodeDecodeError:
        # 如果 utf-8 编码不适用，尝试使用 gb18030 编码
        with open(file_path, 'r', encoding='gb18030') as file:
            text = file.read()
    except FileNotFoundError:
        print(f"Error: The file {file_path} does not exist.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

    # 若是中文文本，则先进行分词操作
    text = chnSegment.word_segment(text)

    # 生成词云
    plotWordcloud.generate_wordcloud(text)
